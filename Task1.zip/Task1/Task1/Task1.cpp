#include "Storages.h"
#include "AirVehicle.h"
#include "GroundVehicle.h"
#include <iostream>


int main()
{
	vector<int> loadingLoads1 = { 1,2,4 };
	vector<int> loadingLoads2 = { 0,3,4 };
	vector<int> loadingLoads3 = { 0,2,3 };
	Load load0(0, 7, 2);
	Load load1(1, 6, 4);
	Load load2(2, 2, 2);
	Load load3(3, 4, 5);
	Load load4(4, 9, 7);
	vector<Load*> unloadingLoads1{ &load0, &load3 };
	vector<Load*> unloadingLoads2{ &load1, &load2 };
	vector<Load*> unloadingLoads3{ &load1, &load4 };
	vector<Load*> spawningLoads1{ &load0, &load3 };
	vector<Load*> spawningLoads2{ &load1, &load2 };
	vector<Load*> spawningLoads3{ &load2,&load4 };
	
	Storage* storage1, *storage2, *storage3, * storage4;
	vector<Storage::StorageDistance*> neighboringStorages1{ new Storage::StorageDistance(storage2,60),
		new Storage::StorageDistance(storage4,224) };
	vector<Storage::StorageDistance*> neighboringStorages2{ new Storage::StorageDistance(storage1,60),
		new Storage::StorageDistance(storage3,118) };
	vector<Storage::StorageDistance*> neighboringStorages3{ new Storage::StorageDistance(storage2,118),
		new Storage::StorageDistance(storage4,85) };
	vector<Storage::StorageDistance*> neighboringStorages4{ new Storage::StorageDistance(storage1,224),
		new Storage::StorageDistance(storage3,85) };
	storage1 = new Storage(loadingLoads1, unloadingLoads1, spawningLoads1, 5);
	storage1 = new Storage(loadingLoads2);
	storage1 = new Storage(loadingLoads3, neighboringStorages3, unloadingLoads2, spawningLoads3, 15);
	storage1 = new Storage(loadingLoads3, neighboringStorages4, unloadingLoads3, spawningLoads3, 20);

	vector<Storage*> storageVec;

	//storageVec.push_back();
	//Storages ukrainianStorages;
}
