#pragma once
#include "Vehicle.h"
class AirVehicle :
	public Vehicle
{
private:
	int moveTime(Storage* from, Storage* to) override
	{
		double dX = this->path->storages.front()->X() - this->path->storages.back()->X();
		double dY = this->path->storages.front()->Y() - this->path->storages.back()->Y();
		return ceil(sqrt(dX * dX + dY * dY) / this->speed);
	}
public:
	/*void CalcualateRoadLength() override
	{
		double dX = this->currentStart->X() - this->currentDestination->X();
		double dY = this->currentStart->Y() - this->currentDestination->Y();
		this->currentRoadLength = sqrt(dX * dX + dY * dY);
	}
	AirVehicle(Storages* storagesSystem, double maxLoadVolume, double maxLoadWeight, int velocity)
	{
		this->storagesSystem = storagesSystem;
		this->maxLoadVolume = maxLoadVolume;
		this->maxLoadWeight = maxLoadWeight;
		this->velocity = velocity;
	}*/
	AirVehicle(double maxVolume, double maxWeight, int speed, Storage* wStorage, int lTime, int uTime)
	{
		this->maxLoadVolume = maxVolume;
		this->maxLoadWeight = maxWeight;
		this->speed = speed;
		this->waitingStorage = wStorage;
		this->loadTime = lTime;
		this->unloadTime = uTime;
	}
};

