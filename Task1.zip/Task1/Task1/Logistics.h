#pragma once
#include "Storage.h"
#include "AirVehicle.h"
#include "GroundVehicle.h"

class Logistics
{
	vector<Storage*> storages;
	vector<Load*> loads;
	vector<Vehicle*> landVehicles;
	vector<Vehicle*> airVehicles;

	Storage* storage(int id);
	Load* load(int type);
	int now = 0;
	Storage* priorityStorage(Load* load);
	Vehicle* priorityVehicle(Storage* storage, Load* load);
public:
	void load(const char* fName);
	void simulate(int endTime);
};
